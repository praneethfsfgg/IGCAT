from flask import Blueprint, flash, g, redirect, render_template, request, session, url_for
from app.db import get_db
from app.security import check_password
from app.utils import audit

bp = Blueprint('auth', __name__)

@bp.route('/', methods=['GET', 'POST'])
@bp.route('/login', methods=['GET', 'POST'])
def login():
    if g.user is not None:
        return redirect(url_for('dashboard.index'))
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        db = get_db()
        user = db.execute('''SELECT u.*, r.role_name FROM User u JOIN Role r ON r.role_id=u.role_id WHERE lower(u.email)=?''', (email,)).fetchone()
        if user is None or not user['active'] or not check_password(user['password_hash'], password):
            if user is not None:
                audit('Login Failed', 'User', user['user_id'], 'Invalid credentials or inactive account', user_id=user['user_id'])
            flash('Invalid email address or password.', 'danger')
            return render_template('login.html', email=email), 401
        session.clear()
        session['user_id'] = user['user_id']
        session.permanent = request.form.get('remember') == 'on'
        audit('Login', 'User', user['user_id'], 'Successful login', user_id=user['user_id'])
        return redirect(request.args.get('next') or url_for('dashboard.index'))
    return render_template('login.html')

@bp.route('/logout', methods=['POST'])
def logout():
    if g.user is not None:
        audit('Logout', 'User', g.user['user_id'], 'User logged out')
    session.clear()
    return redirect(url_for('auth.login'))
