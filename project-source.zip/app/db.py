from flask import current_app, g
from .database import connect, init_database


def get_db():
    if 'db' not in g:
        g.db = connect(current_app.config['DATABASE'])
    return g.db


def close_db(_error=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()


def ensure_database(path):
    conn = init_database(path, reset=False)
    conn.close()
