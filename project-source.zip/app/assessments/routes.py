from datetime import datetime
from flask import Blueprint, abort, flash, g, redirect, render_template, request, url_for
from app.db import get_db
from app.utils import (
    ASSESSMENT_STATUSES, MATURITY_LABELS, PRIORITIES, RISK_RATINGS,
    audit, login_required, user_has_role
)

bp = Blueprint('assessments', __name__, url_prefix='/assessments')


@bp.route('/<int:control_id>', methods=['GET', 'POST'])
@login_required
def assess(control_id):
    db = get_db()
    control = db.execute('''SELECT c.*, u.name owner_name FROM Control c
                            LEFT JOIN User u ON u.user_id=c.owner_id
                            WHERE c.control_id=?''', (control_id,)).fetchone()
    if control is None:
        abort(404)

    # Pure Control Owners can view only their assigned controls. Compliance-capable users can assess all.
    if user_has_role('Control Owner') and not user_has_role('Compliance User') and control['owner_id'] != g.user['user_id']:
        abort(403)

    current = db.execute('''SELECT a.*, u.name assessed_by_name FROM Assessment a
                            JOIN User u ON u.user_id=a.assessed_by
                            WHERE a.control_id=?
                            ORDER BY a.assessed_date DESC, a.assessment_id DESC LIMIT 1''', (control_id,)).fetchone()
    evidence_count = db.execute('SELECT COUNT(*) FROM Evidence WHERE control_id=?', (control_id,)).fetchone()[0]
    owners = db.execute('''SELECT u.user_id,u.name FROM User u JOIN Role r ON r.role_id=u.role_id
                           WHERE u.active=1 AND r.role_name IN ('Control Owner','Control Owner / Compliance User')
                           ORDER BY u.name''').fetchall()
    can_assess = user_has_role('Compliance User')

    if request.method == 'POST':
        if not can_assess:
            abort(403)
        if control['applicability'] != 'Applicable':
            flash('This control is marked Not Applicable and cannot be assessed until applicability is changed.', 'danger')
            return redirect(url_for('assessments.assess', control_id=control_id))

        status = request.form.get('status', '')
        maturity = request.form.get('maturity_level', type=int)
        comments = request.form.get('comments', '').strip()
        risk_rating = request.form.get('risk_rating', '').strip() or None
        risk_rationale = request.form.get('risk_rationale', '').strip() or None
        remediation_required = request.form.get('remediation_required') == 'yes'

        gap_status = status in ('Partially Compliant', 'Non-Compliant')
        if status not in ASSESSMENT_STATUSES or status == 'Not Assessed' or maturity not in MATURITY_LABELS or not comments:
            flash('Status, maturity level and findings are required.', 'danger')
        elif gap_status and (risk_rating not in RISK_RATINGS or not risk_rationale):
            flash('Risk rating and risk rationale are required for identified control gaps.', 'danger')
        elif risk_rating and risk_rating not in RISK_RATINGS:
            flash('Choose a valid risk rating.', 'danger')
        else:
            cur = db.execute('''INSERT INTO Assessment(
                control_id,status,maturity_level,comments,risk_rating,risk_rationale,
                assessed_by,assessed_date,record_context) VALUES(?,?,?,?,?,?,?,?,?)''',
                (control_id, status, maturity, comments, risk_rating, risk_rationale,
                 g.user['user_id'], datetime.now().isoformat(timespec='seconds'),
                 'Demonstration / Academic Prototype'))
            assessment_id = cur.lastrowid

            if remediation_required:
                desc = request.form.get('action_description', '').strip()
                owner_id = request.form.get('owner_id') or None
                priority = request.form.get('priority', '')
                due_date = request.form.get('due_date', '') or None
                if not desc or priority not in PRIORITIES or not owner_id or not due_date:
                    db.rollback()
                    flash('Complete all remediation fields when remediation is required.', 'danger')
                    return render_template(
                        'assessment.html', control=control, current=current, evidence_count=evidence_count,
                        owners=owners, statuses=ASSESSMENT_STATUSES, maturity_labels=MATURITY_LABELS,
                        priorities=PRIORITIES, risk_ratings=RISK_RATINGS, can_assess=can_assess
                    )
                rcur = db.execute('''INSERT INTO RemediationAction(
                    control_id,owner_id,description,priority,status,due_date,created_date,completed_date)
                    VALUES(?,?,?,?,?,?,?,NULL)''',
                    (control_id, owner_id, desc, priority, 'Open', due_date,
                     datetime.now().isoformat(timespec='seconds')))
                audit('Remediation Created', 'RemediationAction', rcur.lastrowid,
                      f'Created from assessment of {control["control_code"]}', commit=False)

            db.commit()
            risk_detail = f'; risk={risk_rating}' if risk_rating else ''
            audit('Assessment Updated', 'Assessment', assessment_id,
                  f'{control["control_code"]} status changed to {status}{risk_detail}')
            flash('Assessment saved successfully.', 'success')
            return redirect(url_for('assessments.assess', control_id=control_id))

    return render_template(
        'assessment.html', control=control, current=current, evidence_count=evidence_count,
        owners=owners, statuses=ASSESSMENT_STATUSES, maturity_labels=MATURITY_LABELS,
        priorities=PRIORITIES, risk_ratings=RISK_RATINGS, can_assess=can_assess
    )
