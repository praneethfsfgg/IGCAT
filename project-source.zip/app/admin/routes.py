from flask import Blueprint, flash, redirect, render_template, request, url_for
from app.db import get_db
from app.security import hash_password
from app.utils import audit, roles_required

bp = Blueprint('admin', __name__, url_prefix='/admin')

@bp.route('/users', methods=['GET','POST'])
@roles_required('Administrator')
def users():
    db=get_db(); roles=db.execute('SELECT * FROM Role ORDER BY role_id').fetchall()
    if request.method=='POST':
        name=request.form.get('name','').strip(); email=request.form.get('email','').strip().lower(); password=request.form.get('password',''); role_id=request.form.get('role_id')
        if not name or not email or not password or not role_id:
            flash('Name, email, password and role are required.','danger')
        else:
            try:
                cur=db.execute('INSERT INTO User(name,email,password_hash,role_id,active) VALUES(?,?,?,?,1)',(name,email,hash_password(password),role_id)); db.commit(); audit('User Created','User',cur.lastrowid,email); flash('User created.','success')
            except Exception:
                db.rollback(); flash('User could not be created. Ensure the email is unique.','danger')
    rows=db.execute('''SELECT u.*, r.role_name FROM User u JOIN Role r ON r.role_id=u.role_id ORDER BY u.name''').fetchall()
    return render_template('user_management.html',users=rows,roles=roles)

@bp.route('/users/<int:user_id>/update', methods=['POST'])
@roles_required('Administrator')
def update_user(user_id):
    db=get_db(); role_id=request.form.get('role_id'); active=1 if request.form.get('active')=='on' else 0
    db.execute('UPDATE User SET role_id=?,active=? WHERE user_id=?',(role_id,active,user_id)); db.commit(); audit('User Updated','User',user_id,'User role/active status updated'); flash('User updated.','success'); return redirect(url_for('admin.users'))
