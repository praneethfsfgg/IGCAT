from functools import wraps
from datetime import date, datetime
from flask import abort, g, redirect, request, url_for
from .db import get_db

ASSESSMENT_STATUSES = ['Compliant', 'Partially Compliant', 'Non-Compliant', 'Not Assessed']
PRIORITIES = ['Critical', 'High', 'Medium', 'Low']
RISK_RATINGS = ['Critical', 'High', 'Medium', 'Low']
REMEDIATION_STATUSES = ['Created', 'Open', 'In Progress', 'Overdue', 'Completed', 'Closed', 'Reopened']
MATURITY_LABELS = {
    1: 'Level 1 – Initial',
    2: 'Level 2 – Developing',
    3: 'Level 3 – Defined',
    4: 'Level 4 – Managed',
}
HYBRID_ROLE = 'Control Owner / Compliance User'


def role_allows(actual_role, required_role):
    if actual_role == HYBRID_ROLE and required_role in ('Control Owner', 'Compliance User'):
        return True
    return actual_role == required_role


def user_has_role(required_role):
    return bool(g.user and role_allows(g.user['role_name'], required_role))


def login_required(view):
    @wraps(view)
    def wrapped(**kwargs):
        if g.user is None:
            return redirect(url_for('auth.login', next=request.path))
        return view(**kwargs)
    return wrapped


def roles_required(*roles):
    def decorator(view):
        @wraps(view)
        @login_required
        def wrapped(**kwargs):
            if not any(role_allows(g.user['role_name'], role) for role in roles):
                abort(403)
            return view(**kwargs)
        return wrapped
    return decorator


def audit(action, entity_type, entity_id=None, details='', user_id=None, commit=True):
    uid = user_id or (g.user['user_id'] if g.user else None)
    if uid is None:
        return
    db = get_db()
    db.execute(
        'INSERT INTO AuditLog(user_id, action, entity_type, entity_id, details, timestamp) VALUES(?,?,?,?,?,?)',
        (uid, action, entity_type, entity_id, details, datetime.now().isoformat(timespec='seconds'))
    )
    if commit:
        db.commit()


def display_action_status(row):
    status = row['status']
    due = row['due_date']
    if status not in ('Completed', 'Closed') and due:
        try:
            if date.fromisoformat(due) < date.today():
                return 'Overdue'
        except ValueError:
            pass
    return status


def latest_control_rows(db):
    return db.execute('''
        SELECT c.*, u.name AS owner_name,
               a.status AS latest_status,
               a.maturity_level AS latest_maturity,
               a.risk_rating AS latest_risk_rating,
               a.risk_rationale AS latest_risk_rationale,
               a.assessed_date AS last_assessed,
               assessor.name AS assessed_by_name
        FROM Control c
        LEFT JOIN User u ON u.user_id=c.owner_id
        LEFT JOIN Assessment a ON a.assessment_id=(
            SELECT a2.assessment_id FROM Assessment a2
            WHERE a2.control_id=c.control_id
            ORDER BY a2.assessed_date DESC, a2.assessment_id DESC LIMIT 1
        )
        LEFT JOIN User assessor ON assessor.user_id=a.assessed_by
        ORDER BY c.control_id
    ''').fetchall()


def calculate_metrics(db, controls=None):
    controls = list(controls if controls is not None else latest_control_rows(db))
    framework_total = len(controls)
    applicable = [c for c in controls if (c['applicability'] or 'Applicable') == 'Applicable']
    not_applicable = framework_total - len(applicable)
    status_counts = {s: 0 for s in ASSESSMENT_STATUSES}
    for c in applicable:
        status = c['latest_status'] or 'Not Assessed'
        status_counts[status] = status_counts.get(status, 0) + 1
    assessed = sum(status_counts.get(s, 0) for s in ('Compliant', 'Partially Compliant', 'Non-Compliant'))
    compliant = status_counts.get('Compliant', 0)
    overall = round((compliant / assessed) * 100) if assessed else 0
    open_gaps = status_counts.get('Partially Compliant', 0) + status_counts.get('Non-Compliant', 0)
    return {
        'overall_compliance': overall,
        'total_controls': framework_total,
        'applicable_controls': len(applicable),
        'not_applicable_controls': not_applicable,
        'open_gaps': open_gaps,
        'status_counts': status_counts,
        'assessed_controls': assessed,
        'unassessed_controls': status_counts.get('Not Assessed', 0),
    }
