import sqlite3
from pathlib import Path

SCHEMA = r'''
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS Role (
    role_id INTEGER PRIMARY KEY,
    role_name TEXT NOT NULL UNIQUE,
    description TEXT
);

CREATE TABLE IF NOT EXISTS User (
    user_id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role_id INTEGER NOT NULL,
    active BOOLEAN NOT NULL DEFAULT 1,
    FOREIGN KEY (role_id) REFERENCES Role(role_id)
);

CREATE TABLE IF NOT EXISTS Control (
    control_id INTEGER PRIMARY KEY,
    control_code TEXT NOT NULL UNIQUE,
    title TEXT NOT NULL,
    description TEXT,
    category TEXT NOT NULL,
    framework TEXT NOT NULL DEFAULT 'ISO/IEC 27001:2022 Annex A',
    applicability TEXT NOT NULL DEFAULT 'Applicable',
    applicability_rationale TEXT,
    owner_id INTEGER,
    created_date DATETIME NOT NULL,
    FOREIGN KEY (owner_id) REFERENCES User(user_id)
);

CREATE TABLE IF NOT EXISTS Assessment (
    assessment_id INTEGER PRIMARY KEY,
    control_id INTEGER NOT NULL,
    status TEXT NOT NULL,
    maturity_level INTEGER,
    comments TEXT,
    risk_rating TEXT,
    risk_rationale TEXT,
    assessed_by INTEGER NOT NULL,
    assessed_date DATETIME NOT NULL,
    record_context TEXT NOT NULL DEFAULT 'Demonstration / Academic Prototype',
    FOREIGN KEY (control_id) REFERENCES Control(control_id),
    FOREIGN KEY (assessed_by) REFERENCES User(user_id)
);

CREATE TABLE IF NOT EXISTS Evidence (
    evidence_id INTEGER PRIMARY KEY,
    control_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    file_name TEXT NOT NULL,
    file_path TEXT NOT NULL,
    uploaded_by INTEGER NOT NULL,
    uploaded_date DATETIME NOT NULL,
    FOREIGN KEY (control_id) REFERENCES Control(control_id),
    FOREIGN KEY (uploaded_by) REFERENCES User(user_id)
);

CREATE TABLE IF NOT EXISTS RemediationAction (
    action_id INTEGER PRIMARY KEY,
    control_id INTEGER NOT NULL,
    owner_id INTEGER,
    description TEXT NOT NULL,
    priority TEXT NOT NULL,
    status TEXT NOT NULL,
    due_date DATE,
    created_date DATETIME NOT NULL,
    completed_date DATETIME,
    FOREIGN KEY (control_id) REFERENCES Control(control_id),
    FOREIGN KEY (owner_id) REFERENCES User(user_id)
);

CREATE TABLE IF NOT EXISTS AuditLog (
    log_id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL,
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id INTEGER,
    details TEXT,
    timestamp DATETIME NOT NULL,
    FOREIGN KEY (user_id) REFERENCES User(user_id)
);

CREATE INDEX IF NOT EXISTS idx_assessment_control_date ON Assessment(control_id, assessed_date DESC);
CREATE INDEX IF NOT EXISTS idx_evidence_control ON Evidence(control_id);
CREATE INDEX IF NOT EXISTS idx_remediation_control ON RemediationAction(control_id);
CREATE INDEX IF NOT EXISTS idx_remediation_owner ON RemediationAction(owner_id);
CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON AuditLog(timestamp DESC);
'''


def connect(path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    return conn


def _columns(conn, table):
    return {row['name'] for row in conn.execute(f'PRAGMA table_info({table})').fetchall()}


def migrate_database(conn):
    """Small additive migration so an older prototype DB can still start safely."""
    control_cols = _columns(conn, 'Control')
    for name, ddl in [
        ('framework', "TEXT NOT NULL DEFAULT 'ISO/IEC 27001:2022 Annex A'"),
        ('applicability', "TEXT NOT NULL DEFAULT 'Applicable'"),
        ('applicability_rationale', 'TEXT'),
    ]:
        if name not in control_cols:
            conn.execute(f'ALTER TABLE Control ADD COLUMN {name} {ddl}')

    assessment_cols = _columns(conn, 'Assessment')
    for name, ddl in [
        ('risk_rating', 'TEXT'),
        ('risk_rationale', 'TEXT'),
        ('record_context', "TEXT NOT NULL DEFAULT 'Demonstration / Academic Prototype'"),
    ]:
        if name not in assessment_cols:
            conn.execute(f'ALTER TABLE Assessment ADD COLUMN {name} {ddl}')
    conn.commit()


def init_database(path, reset=False):
    path = Path(path)
    if reset and path.exists():
        path.unlink()
    conn = connect(path)
    conn.executescript(SCHEMA)
    migrate_database(conn)
    conn.commit()
    return conn
