import base64
import hashlib
import hmac
import secrets

ALGORITHM = 'pbkdf2_sha256'
ITERATIONS = 260_000


def hash_password(password: str) -> str:
    if not password:
        raise ValueError('Password cannot be empty.')
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, ITERATIONS)
    return f'{ALGORITHM}${ITERATIONS}${base64.urlsafe_b64encode(salt).decode()}${base64.urlsafe_b64encode(digest).decode()}'


def check_password(stored: str, candidate: str) -> bool:
    try:
        algorithm, iterations, salt_b64, digest_b64 = stored.split('$', 3)
        if algorithm != ALGORITHM:
            return False
        salt = base64.urlsafe_b64decode(salt_b64.encode())
        expected = base64.urlsafe_b64decode(digest_b64.encode())
        actual = hashlib.pbkdf2_hmac('sha256', candidate.encode('utf-8'), salt, int(iterations))
        return hmac.compare_digest(expected, actual)
    except Exception:
        return False
