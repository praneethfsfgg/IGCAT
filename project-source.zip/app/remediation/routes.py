from datetime import datetime
from math import ceil
from flask import Blueprint, abort, flash, g, redirect, render_template, request, url_for
from app.db import get_db
from app.utils import PRIORITIES, REMEDIATION_STATUSES, audit, display_action_status, login_required, user_has_role

bp = Blueprint('remediation', __name__, url_prefix='/remediation')


@bp.route('/')
@login_required
def index():
    db = get_db()
    rows = list(db.execute('''SELECT r.*, c.control_code, c.title control_title, u.name owner_name
                              FROM RemediationAction r JOIN Control c ON c.control_id=r.control_id
                              LEFT JOIN User u ON u.user_id=r.owner_id ORDER BY r.action_id''').fetchall())
    if user_has_role('Control Owner') and not user_has_role('Compliance User'):
        rows = [r for r in rows if r['owner_id'] == g.user['user_id']]

    q = request.args.get('q', '').strip().lower()
    status = request.args.get('status', '')
    priority = request.args.get('priority', '')
    owner = request.args.get('owner', '')
    due = request.args.get('due_date', '')
    enriched = [(r, display_action_status(r)) for r in rows]
    if q:
        enriched = [(r, s) for r, s in enriched if q in f"RA-{r['action_id']:03d}".lower() or q in r['control_code'].lower() or q in r['description'].lower()]
    if status:
        enriched = [(r, s) for r, s in enriched if s == status]
    if priority:
        enriched = [(r, s) for r, s in enriched if r['priority'] == priority]
    if owner:
        enriched = [(r, s) for r, s in enriched if str(r['owner_id'] or '') == owner]
    if due:
        enriched = [(r, s) for r, s in enriched if r['due_date'] == due]

    all_rows = [(r, display_action_status(r)) for r in rows]
    counts = {s: sum(1 for _, shown in all_rows if shown == s) for s in REMEDIATION_STATUSES}
    owners = db.execute('''SELECT u.user_id,u.name FROM User u JOIN Role r ON r.role_id=u.role_id
                           WHERE u.active=1 AND r.role_name IN ('Control Owner','Control Owner / Compliance User')
                           ORDER BY u.name''').fetchall()
    page = max(1, request.args.get('page', 1, type=int))
    per_page = 10
    pages = max(1, ceil(len(enriched) / per_page))
    page = min(page, pages)
    return render_template(
        'remediation_actions.html', actions=enriched[(page - 1) * per_page:page * per_page],
        counts=counts, owners=owners, priorities=PRIORITIES, statuses=REMEDIATION_STATUSES,
        page=page, pages=pages, total=len(enriched)
    )


@bp.route('/create', methods=['GET', 'POST'])
@login_required
def create():
    if not user_has_role('Compliance User'):
        abort(403)
    db = get_db()
    controls = db.execute("SELECT control_id,control_code,title FROM Control WHERE applicability='Applicable' ORDER BY control_id").fetchall()
    owners = db.execute('''SELECT u.user_id,u.name FROM User u JOIN Role r ON r.role_id=u.role_id
                           WHERE u.active=1 AND r.role_name IN ('Control Owner','Control Owner / Compliance User')
                           ORDER BY u.name''').fetchall()
    if request.method == 'POST':
        control_id = request.form.get('control_id')
        owner_id = request.form.get('owner_id')
        desc = request.form.get('description', '').strip()
        priority = request.form.get('priority', '')
        due = request.form.get('due_date', '')
        if not control_id or not owner_id or not desc or priority not in PRIORITIES or not due:
            flash('All remediation fields are required.', 'danger')
        else:
            cur = db.execute('''INSERT INTO RemediationAction(control_id,owner_id,description,priority,status,due_date,created_date,completed_date)
                                VALUES(?,?,?,?,?,?,?,NULL)''',
                             (control_id, owner_id, desc, priority, 'Open', due,
                              datetime.now().isoformat(timespec='seconds')))
            db.commit()
            audit('Remediation Created', 'RemediationAction', cur.lastrowid, desc)
            flash('Remediation action created.', 'success')
            return redirect(url_for('remediation.index'))
    return render_template('remediation_form.html', controls=controls, owners=owners, priorities=PRIORITIES,
                           action=None, statuses=REMEDIATION_STATUSES)


@bp.route('/<int:action_id>/update', methods=['GET', 'POST'])
@login_required
def update(action_id):
    db = get_db()
    action = db.execute('''SELECT r.*, c.control_code FROM RemediationAction r
                           JOIN Control c ON c.control_id=r.control_id WHERE action_id=?''', (action_id,)).fetchone()
    if action is None:
        abort(404)
    can_update = user_has_role('Compliance User') or (
        user_has_role('Control Owner') and action['owner_id'] == g.user['user_id']
    )
    if not can_update:
        abort(403)
    if request.method == 'POST':
        status = request.form.get('status', '')
        if status not in REMEDIATION_STATUSES:
            flash('Choose a valid status.', 'danger')
        else:
            completed = datetime.now().isoformat(timespec='seconds') if status in ('Completed', 'Closed') else None
            db.execute('UPDATE RemediationAction SET status=?,completed_date=? WHERE action_id=?',
                       (status, completed, action_id))
            db.commit()
            audit('Remediation Updated', 'RemediationAction', action_id,
                  f'RA-{action_id:03d} status changed to {status}')
            flash('Remediation action updated.', 'success')
            return redirect(url_for('remediation.index'))
    return render_template('remediation_update.html', action=action, statuses=REMEDIATION_STATUSES,
                           display_status=display_action_status(action))
