document.addEventListener('DOMContentLoaded',()=>{
  const show=document.getElementById('showPassword'), pwd=document.getElementById('password');
  if(show&&pwd) show.addEventListener('change',()=>{pwd.type=show.checked?'text':'password';});
});
function toggleRemediation(show){const el=document.getElementById('remediationFields'); if(el) el.classList.toggle('d-none',!show);}
