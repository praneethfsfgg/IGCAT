from datetime import date, timedelta
from io import BytesIO
from flask import Blueprint, abort, g, render_template, request, send_file
from app.db import get_db
from app.pdf_utils import simple_text_pdf
from app.utils import (
    ASSESSMENT_STATUSES, audit, calculate_metrics, display_action_status,
    latest_control_rows, login_required, user_has_role
)

bp = Blueprint('reports', __name__, url_prefix='/reports')
REPORT_TYPES = ['Compliance Summary', 'Control Status Report', 'Remediation Status Report', 'Overdue Actions Report', 'Assessment Summary']
PERIODS = ['Current', 'Last 30 Days', 'Last Quarter', 'Custom']


def _period_bounds(period, start_date='', end_date=''):
    today = date.today()
    if period == 'Last 30 Days':
        return today - timedelta(days=30), today
    if period == 'Last Quarter':
        return today - timedelta(days=90), today
    if period == 'Custom':
        try:
            start = date.fromisoformat(start_date) if start_date else None
            end = date.fromisoformat(end_date) if end_date else None
            return start, end
        except ValueError:
            return None, None
    return None, None


def _within_period(control, start, end):
    if start is None and end is None:
        return True
    if not control['last_assessed']:
        return False
    try:
        assessed = date.fromisoformat(control['last_assessed'][:10])
    except ValueError:
        return False
    if start and assessed < start:
        return False
    if end and assessed > end:
        return False
    return True


def build_report(db, values):
    controls = list(latest_control_rows(db))
    report_type = values.get('report_type', 'Compliance Summary')
    if report_type not in REPORT_TYPES:
        report_type = 'Compliance Summary'
    period = values.get('period', 'Current')
    if period not in PERIODS:
        period = 'Current'
    category = values.get('category', '')
    status = values.get('status', '')
    start_date = values.get('start_date', '')
    end_date = values.get('end_date', '')

    start, end = _period_bounds(period, start_date, end_date)
    if period != 'Current':
        controls = [c for c in controls if _within_period(c, start, end)]
    if category:
        controls = [c for c in controls if c['category'] == category]
    if status:
        controls = [c for c in controls if (c['latest_status'] or 'Not Assessed') == status]

    metrics = calculate_metrics(db, controls)
    control_ids = {c['control_id'] for c in controls}
    actions = list(db.execute('''SELECT r.*, c.control_code FROM RemediationAction r
                                 JOIN Control c ON c.control_id=r.control_id ORDER BY r.action_id''').fetchall())
    relevant = [a for a in actions if a['control_id'] in control_ids]
    overdue_actions = [a for a in relevant if display_action_status(a) == 'Overdue']
    active_actions = [a for a in relevant if display_action_status(a) not in ('Completed', 'Closed')]
    completed_actions = [a for a in relevant if display_action_status(a) in ('Completed', 'Closed')]
    progress_total = len(relevant)
    remediation_progress = round((len(completed_actions) / progress_total) * 100) if progress_total else 0

    high_priority = [a for a in relevant if a['priority'] in ('Critical', 'High') and display_action_status(a) not in ('Completed', 'Closed')]
    if report_type == 'Control Status Report':
        detail_kind = 'controls'
        detail_rows = controls[:15]
        outstanding = high_priority[:12]
    elif report_type == 'Assessment Summary':
        detail_kind = 'assessments'
        detail_rows = [c for c in controls if c['latest_status']][:15]
        outstanding = high_priority[:12]
    elif report_type == 'Remediation Status Report':
        detail_kind = 'remediation'
        detail_rows = relevant[:15]
        outstanding = high_priority[:12]
    elif report_type == 'Overdue Actions Report':
        detail_kind = 'overdue'
        detail_rows = overdue_actions[:15]
        outstanding = overdue_actions[:12]
    else:
        detail_kind = 'summary'
        detail_rows = high_priority[:12]
        outstanding = high_priority[:12]

    return {
        'controls': controls,
        'metrics': metrics,
        'overdue': len(overdue_actions),
        'outstanding': outstanding,
        'detail_kind': detail_kind,
        'detail_rows': detail_rows,
        'active_actions': len(active_actions),
        'completed_actions': len(completed_actions),
        'remediation_progress': remediation_progress,
        'report_type': report_type,
        'period': period,
        'category': category,
        'status': status,
        'start_date': start_date,
        'end_date': end_date,
    }


@bp.route('/', methods=['GET', 'POST'])
@login_required
def index():
    if not (user_has_role('Administrator') or user_has_role('Compliance User')):
        abort(403)
    db = get_db()
    data = build_report(db, request.values)
    categories = [r['category'] for r in db.execute('SELECT DISTINCT category FROM Control ORDER BY category')]
    if request.method == 'POST':
        audit('Report Generated', 'Report', None,
              f"{data['report_type']}; period={data['period']}; category={data['category'] or 'All'}; status={data['status'] or 'All'}")
    return render_template(
        'reports.html', categories=categories, statuses=ASSESSMENT_STATUSES,
        report_types=REPORT_TYPES, periods=PERIODS, **data
    )


@bp.route('/export.pdf')
@login_required
def export_pdf():
    if not (user_has_role('Administrator') or user_has_role('Compliance User')):
        abort(403)
    db = get_db()
    data = build_report(db, request.args)
    lines = [
        'Demonstration / Academic Prototype - sample data only',
        f"Report type: {data['report_type']}",
        f"Reporting period: {data['period']}",
        f"Category: {data['category'] or 'All Categories'}",
        f"Compliance status filter: {data['status'] or 'All Statuses'}",
        f"Overall compliance: {data['metrics']['overall_compliance']}%",
        f"Applicable controls in report: {data['metrics']['applicable_controls']}",
        f"Assessed controls: {data['metrics']['assessed_controls']}",
        f"Open gaps: {data['metrics']['open_gaps']}",
        f"Overdue remediation actions: {data['overdue']}",
        f"Remediation progress: {data['remediation_progress']}%",
        'Control status breakdown:',
    ]
    for status_name, count in data['metrics']['status_counts'].items():
        lines.append(f'  {status_name}: {count}')
    lines.append('Key outstanding items:')
    for action in data['outstanding'][:10]:
        lines.append(f"  RA-{action['action_id']:03d} | {action['control_code']} | {action['priority']} | due {action['due_date']}")
    pdf_bytes = simple_text_pdf(lines)
    buffer = BytesIO(pdf_bytes)
    audit('Report Exported', 'Report', None, f"PDF export: {data['report_type']}")
    return send_file(buffer, mimetype='application/pdf', as_attachment=True, download_name='ISMS_Compliance_Report.pdf')
