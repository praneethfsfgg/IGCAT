from math import ceil
from datetime import date
from flask import Blueprint, render_template, request
from app.db import get_db
from app.utils import roles_required

bp = Blueprint('audit', __name__, url_prefix='/audit')

@bp.route('/')
@roles_required('Administrator')
def index():
    db=get_db(); rows=list(db.execute('''SELECT l.*, u.name, r.role_name FROM AuditLog l JOIN User u ON u.user_id=l.user_id JOIN Role r ON r.role_id=u.role_id ORDER BY l.timestamp DESC,l.log_id DESC''').fetchall())
    q=request.args.get('q','').strip().lower(); user=request.args.get('user',''); action=request.args.get('action',''); date_from=request.args.get('date_from',''); date_to=request.args.get('date_to','')
    if q: rows=[r for r in rows if q in r['name'].lower() or q in r['action'].lower() or q in (r['details'] or '').lower()]
    if user: rows=[r for r in rows if str(r['user_id'])==user]
    if action: rows=[r for r in rows if action.lower() in r['action'].lower()]
    if date_from: rows=[r for r in rows if r['timestamp'][:10] >= date_from]
    if date_to: rows=[r for r in rows if r['timestamp'][:10] <= date_to]
    users=db.execute('SELECT user_id,name FROM User ORDER BY name').fetchall(); today=date.today().isoformat()
    summary={
        'activities_today': db.execute('SELECT COUNT(*) FROM AuditLog WHERE substr(timestamp,1,10)=?',(today,)).fetchone()[0],
        'users_active': db.execute('SELECT COUNT(*) FROM User WHERE active=1').fetchone()[0],
        'assessments_updated': db.execute("SELECT COUNT(*) FROM AuditLog WHERE action='Assessment Updated'").fetchone()[0],
        'evidence_uploads': db.execute("SELECT COUNT(*) FROM AuditLog WHERE action='Evidence Uploaded'").fetchone()[0],
    }
    page=max(1,request.args.get('page',1,type=int)); per_page=12; pages=max(1,ceil(len(rows)/per_page)); page=min(page,pages)
    return render_template('audit_log.html',logs=rows[(page-1)*per_page:page*per_page],users=users,summary=summary,page=page,pages=pages,total=len(rows))
