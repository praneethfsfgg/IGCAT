from collections import Counter
from flask import Blueprint, g, render_template
from app.db import get_db
from app.utils import calculate_metrics, display_action_status, latest_control_rows, login_required, user_has_role

bp = Blueprint('dashboard', __name__, url_prefix='/dashboard')


@bp.route('/')
@login_required
def index():
    db = get_db()
    controls = list(latest_control_rows(db))
    if user_has_role('Control Owner') and not user_has_role('Compliance User'):
        controls = [c for c in controls if c['owner_id'] == g.user['user_id']]
    metrics = calculate_metrics(db, controls)

    actions = list(db.execute('''SELECT r.*, c.control_code, u.name owner_name FROM RemediationAction r
                                 JOIN Control c ON c.control_id=r.control_id
                                 LEFT JOIN User u ON u.user_id=r.owner_id ORDER BY r.action_id''').fetchall())
    if user_has_role('Control Owner') and not user_has_role('Compliance User'):
        actions = [a for a in actions if a['owner_id'] == g.user['user_id']]
    display_statuses = [display_action_status(a) for a in actions]
    remediation_counts = Counter(display_statuses)
    overdue_actions = remediation_counts.get('Overdue', 0)
    attention = []
    for action in actions:
        shown = display_action_status(action)
        if action['priority'] in ('Critical', 'High') and shown not in ('Completed', 'Closed'):
            attention.append((action, shown))

    recent = db.execute('''SELECT l.*, u.name, r.role_name FROM AuditLog l
                           JOIN User u ON u.user_id=l.user_id JOIN Role r ON r.role_id=u.role_id
                           ORDER BY l.timestamp DESC, l.log_id DESC LIMIT 5''').fetchall()
    featured = db.execute("SELECT control_id FROM Control WHERE control_code='A.5.15'").fetchone()
    return render_template(
        'dashboard.html', metrics=metrics, remediation_counts=remediation_counts,
        overdue_actions=overdue_actions, attention=attention[:5], recent=recent,
        featured_control_id=(featured['control_id'] if featured else 1)
    )
