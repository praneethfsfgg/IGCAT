from math import ceil
from datetime import datetime
from flask import Blueprint, flash, g, redirect, render_template, request, url_for
from app.db import get_db
from app.utils import ASSESSMENT_STATUSES, MATURITY_LABELS, audit, latest_control_rows, login_required, roles_required, user_has_role

bp = Blueprint('controls', __name__, url_prefix='/controls')


@bp.route('/')
@login_required
def index():
    db = get_db()
    rows = list(latest_control_rows(db))
    if user_has_role('Control Owner') and not user_has_role('Compliance User'):
        rows = [r for r in rows if r['owner_id'] == g.user['user_id']]

    q = request.args.get('q', '').strip().lower()
    category = request.args.get('category', '')
    status = request.args.get('status', '')
    owner = request.args.get('owner', '')
    applicability = request.args.get('applicability', '')
    if q:
        rows = [r for r in rows if q in r['control_code'].lower() or q in r['title'].lower()]
    if category:
        rows = [r for r in rows if r['category'] == category]
    if status:
        rows = [r for r in rows if (r['latest_status'] or 'Not Assessed') == status]
    if owner:
        rows = [r for r in rows if str(r['owner_id'] or '') == owner]
    if applicability:
        rows = [r for r in rows if r['applicability'] == applicability]

    categories = [r['category'] for r in db.execute('SELECT DISTINCT category FROM Control ORDER BY category')]
    owners = db.execute('''SELECT u.user_id,u.name FROM User u JOIN Role r ON r.role_id=u.role_id
                           WHERE u.active=1 AND r.role_name IN ('Control Owner','Control Owner / Compliance User')
                           ORDER BY u.name''').fetchall()
    page = max(1, request.args.get('page', 1, type=int))
    per_page = 10
    pages = max(1, ceil(len(rows) / per_page))
    page = min(page, pages)
    display_rows = rows[(page - 1) * per_page:page * per_page]
    return render_template(
        'control_register.html', controls=display_rows, categories=categories, owners=owners,
        assessment_statuses=ASSESSMENT_STATUSES, maturity_labels=MATURITY_LABELS,
        page=page, pages=pages, total=len(rows)
    )


@bp.route('/add', methods=['GET', 'POST'])
@roles_required('Administrator')
def add():
    db = get_db()
    owners = db.execute('''SELECT u.user_id,u.name FROM User u JOIN Role r ON r.role_id=u.role_id
                           WHERE u.active=1 AND r.role_name IN ('Control Owner','Control Owner / Compliance User')
                           ORDER BY u.name''').fetchall()
    if request.method == 'POST':
        code = request.form.get('control_code', '').strip().upper()
        title = request.form.get('title', '').strip()
        category = request.form.get('category', '').strip()
        description = request.form.get('description', '').strip()
        framework = request.form.get('framework', '').strip() or 'ISO/IEC 27001:2022 Annex A'
        applicability = request.form.get('applicability', 'Applicable')
        rationale = request.form.get('applicability_rationale', '').strip()
        owner_id = request.form.get('owner_id') or None
        if not code or not title or not category or applicability not in ('Applicable', 'Not Applicable'):
            flash('Control code, title, category and valid applicability are required.', 'danger')
        else:
            try:
                cur = db.execute('''INSERT INTO Control(
                    control_code,title,description,category,framework,applicability,
                    applicability_rationale,owner_id,created_date) VALUES(?,?,?,?,?,?,?,?,?)''',
                    (code, title, description, category, framework, applicability, rationale,
                     owner_id, datetime.now().isoformat(timespec='seconds')))
                db.commit()
                audit('Control Created', 'Control', cur.lastrowid, f'{code} {title}')
                flash('Control created successfully.', 'success')
                return redirect(url_for('controls.index'))
            except Exception:
                db.rollback()
                flash('Control could not be created. Ensure the code is unique.', 'danger')
    return render_template('control_add.html', owners=owners)
