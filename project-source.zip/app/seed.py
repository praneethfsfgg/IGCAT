from datetime import date, datetime, timedelta
from .security import hash_password

DEMO_PASSWORD = 'DemoPass!2026'
FRAMEWORK = 'ISO/IEC 27001:2022 Annex A'

# Control identifiers and short titles provide traceability to ISO/IEC 27001:2022 Annex A.
# Descriptions below are deliberately concise academic-prototype summaries, not normative ISO text.
ISO_CONTROLS = [
    ('A.5.1', 'Policies for information security', 'Defines, approves, communicates and periodically reviews information security policies so they remain aligned with business and security requirements.'),
    ('A.5.2', 'Information security roles and responsibilities', 'Assigns and communicates information security responsibilities so accountability for security activities and decisions is clear.'),
    ('A.5.3', 'Segregation of duties', 'Separates conflicting duties and areas of responsibility to reduce opportunities for error, misuse or unauthorized activity.'),
    ('A.5.4', 'Management responsibilities', 'Requires managers to ensure personnel follow established information security policies, procedures and assigned responsibilities.'),
    ('A.5.5', 'Contact with authorities', 'Maintains appropriate contacts with regulators, law enforcement and other authorities for security incidents, obligations and coordination.'),
    ('A.5.6', 'Contact with special interest groups', 'Maintains relevant professional and specialist security contacts to exchange knowledge, warnings and good practices.'),
    ('A.5.7', 'Threat intelligence', 'Collects and analyses threat information so emerging threats can be understood and appropriate defensive actions can be taken.'),
    ('A.5.8', 'Information security in project management', 'Integrates information security requirements and risk considerations into project governance and delivery activities.'),
    ('A.5.9', 'Inventory of information and associated assets', 'Maintains an accurate inventory of information and associated assets, including ownership and relevant security information.'),
    ('A.5.10', 'Acceptable use of information and associated assets', 'Establishes acceptable-use rules for information and associated assets to prevent misuse, loss and unauthorized handling.'),
    ('A.5.11', 'Return of assets', 'Ensures organisational assets are returned when personnel, contractors or other users leave or change roles.'),
    ('A.5.12', 'Classification of information', 'Classifies information according to sensitivity, value, legal obligations and the protection it requires.'),
    ('A.5.13', 'Labelling of information', 'Uses appropriate labels or markings to communicate the classification and handling requirements of information.'),
    ('A.5.14', 'Information transfer', 'Protects information transferred within or outside the organisation through approved methods, agreements and safeguards.'),
    ('A.5.15', 'Access control', 'Defines and applies physical and logical access-control rules based on business need, least privilege and security requirements.'),
    ('A.5.16', 'Identity management', 'Manages digital identities throughout their lifecycle so identities are uniquely assigned, maintained and removed when no longer required.'),
    ('A.5.17', 'Authentication information', 'Protects passwords, keys, tokens and other authentication information during creation, distribution, storage, use and replacement.'),
    ('A.5.18', 'Access rights', 'Provisions, reviews, modifies and removes access rights so permissions remain appropriate to current responsibilities.'),
    ('A.5.19', 'Information security in supplier relationships', 'Identifies and manages information security risks arising from suppliers and third-party relationships.'),
    ('A.5.20', 'Information security within supplier agreements', 'Defines relevant information security requirements and responsibilities within supplier agreements and contracts.'),
    ('A.5.21', 'Managing information security in the ICT supply chain', 'Manages information security risks throughout the ICT supply chain, including products, services and dependent suppliers.'),
    ('A.5.22', 'Monitoring, review and change management of supplier services', 'Monitors supplier services, reviews security performance and controls changes that could affect agreed security requirements.'),
    ('A.5.23', 'Information security for use of cloud services', 'Establishes governance for acquiring, using, managing and exiting cloud services in accordance with security requirements.'),
    ('A.5.24', 'Information security incident management planning and preparation', 'Prepares incident-management processes, responsibilities, communications and resources so security incidents can be handled effectively.'),
    ('A.5.25', 'Assessment and decision on information security events', 'Assesses reported information security events and decides whether they should be classified and managed as security incidents.'),
    ('A.5.26', 'Response to information security incidents', 'Responds to information security incidents using defined containment, communication, recovery and resolution procedures.'),
    ('A.5.27', 'Learning from information security incidents', 'Uses lessons from security incidents to improve controls, procedures, awareness and future incident response.'),
    ('A.5.28', 'Collection of evidence', 'Identifies, collects, preserves and handles evidence so it remains reliable and usable for investigations or legal processes.'),
    ('A.5.29', 'Information security during disruption', 'Maintains appropriate information security controls during disruption so critical information remains protected.'),
    ('A.5.30', 'ICT readiness for business continuity', 'Plans and tests ICT readiness so technology services can support required business continuity and recovery objectives.'),
    ('A.5.31', 'Legal, statutory, regulatory and contractual requirements', 'Identifies and maintains applicable legal, statutory, regulatory and contractual information security requirements.'),
    ('A.5.32', 'Intellectual property rights', 'Protects intellectual property and ensures software, content and other protected materials are used in accordance with rights and licences.'),
    ('A.5.33', 'Protection of records', 'Protects records against loss, destruction, falsification, unauthorized access and unauthorized release throughout required retention periods.'),
    ('A.5.34', 'Privacy and protection of personally identifiable information', 'Protects personally identifiable information in accordance with privacy obligations, organisational requirements and applicable law.'),
    ('A.5.35', 'Independent review of information security', 'Provides objective, independent review of the information security program and controls at planned intervals or after significant changes.'),
    ('A.5.36', 'Compliance with information security policies and standards', 'Checks compliance with information security policies, standards and rules and addresses identified non-conformities.'),
    ('A.5.37', 'Documented operating procedures', 'Documents operating procedures where consistent and secure execution of information-processing activities is required.'),
    ('A.6.1', 'Screening', 'Performs proportionate background screening before and, where appropriate, during engagement to reduce personnel-related security risk.'),
    ('A.6.2', 'Terms and conditions of employment', 'Includes relevant information security responsibilities and obligations in employment or engagement terms and conditions.'),
    ('A.6.3', 'Information security awareness, education and training', 'Provides ongoing security awareness, education and training so personnel understand threats, responsibilities and expected secure behaviour.'),
    ('A.6.4', 'Disciplinary process', 'Maintains a formal disciplinary process for violations of information security policies and responsibilities.'),
    ('A.6.5', 'Responsibilities after termination or change of employment', 'Manages continuing and changed security responsibilities when employment or contractual relationships end or roles change.'),
    ('A.6.6', 'Confidentiality or non-disclosure agreements', 'Uses confidentiality or non-disclosure agreements where required to protect sensitive information from unauthorized disclosure.'),
    ('A.6.7', 'Remote working', 'Applies security measures to remote working environments, devices, connections and information handled outside organisational premises.'),
    ('A.6.8', 'Information security event reporting', 'Provides clear mechanisms for personnel to promptly report suspected or observed information security events.'),
    ('A.7.1', 'Physical security perimeters', 'Defines and protects physical security boundaries around areas containing information and other sensitive assets.'),
    ('A.7.2', 'Physical entry', 'Controls and records physical entry so only authorized people can access secured premises and areas.'),
    ('A.7.3', 'Securing offices, rooms and facilities', 'Designs and secures offices, rooms and facilities to reduce unauthorized physical access, damage and interference.'),
    ('A.7.4', 'Physical security monitoring', 'Monitors premises and sensitive areas to detect and investigate unauthorized physical access or suspicious activity.'),
    ('A.7.5', 'Protection against physical and environmental threats', 'Protects premises, equipment and information from environmental hazards, natural events and deliberate physical threats.'),
    ('A.7.6', 'Working in secure areas', 'Establishes secure working practices for personnel operating within designated secure areas.'),
    ('A.7.7', 'Clear desk and clear screen', 'Requires sensitive information to be cleared from unattended workspaces and screens protected from unauthorized viewing.'),
    ('A.7.8', 'Equipment siting and protection', 'Places and protects equipment to reduce risks from unauthorized access, environmental hazards, damage and interference.'),
    ('A.7.9', 'Security of assets off-premises', 'Protects organisational assets used or stored away from organisational premises against loss, theft, damage and unauthorized access.'),
    ('A.7.10', 'Storage media', 'Manages storage media throughout its lifecycle, including handling, transport, reuse and disposal, according to information sensitivity.'),
    ('A.7.11', 'Supporting utilities', 'Protects supporting utilities such as power and communications from failures or disruptions that could affect information-processing facilities.'),
    ('A.7.12', 'Cabling security', 'Protects power and data cabling from interception, interference, accidental damage and unauthorized connection.'),
    ('A.7.13', 'Equipment maintenance', 'Maintains equipment correctly and securely to preserve availability, integrity and protection of information.'),
    ('A.7.14', 'Secure disposal or re-use of equipment', 'Removes or securely destroys information and licensed software before equipment is disposed of, transferred or reused.'),
    ('A.8.1', 'User endpoint devices', 'Secures user endpoint devices through appropriate configuration, access controls, protection, maintenance and user responsibilities.'),
    ('A.8.2', 'Privileged access rights', 'Restricts and manages privileged access rights so elevated permissions are granted only when justified and are regularly reviewed.'),
    ('A.8.3', 'Information access restriction', 'Restricts access to information and application functions according to approved access-control policies and business need.'),
    ('A.8.4', 'Access to source code', 'Controls access to source code, development tools and related repositories to prevent unauthorized viewing or modification.'),
    ('A.8.5', 'Secure authentication', 'Implements secure authentication methods appropriate to the sensitivity of systems, information and access risks.'),
    ('A.8.6', 'Capacity management', 'Monitors and manages resource capacity so systems can meet current and expected availability and performance requirements.'),
    ('A.8.7', 'Protection against malware', 'Prevents, detects and responds to malware using technical controls, secure practices, monitoring and user awareness.'),
    ('A.8.8', 'Management of technical vulnerabilities', 'Identifies, assesses and remediates technical vulnerabilities according to risk, exposure and defined timeframes.'),
    ('A.8.9', 'Configuration management', 'Defines, implements, monitors and controls secure configurations for hardware, software, services and networks.'),
    ('A.8.10', 'Information deletion', 'Deletes information from systems, devices and storage media when it is no longer required, subject to retention obligations.'),
    ('A.8.11', 'Data masking', 'Masks sensitive data where appropriate to reduce unnecessary exposure while preserving authorised business use.'),
    ('A.8.12', 'Data leakage prevention', 'Applies measures to detect and prevent unauthorized disclosure, extraction or transfer of sensitive information.'),
    ('A.8.13', 'Information backup', 'Creates, protects and tests backups so information and systems can be restored following loss, corruption or disruption.'),
    ('A.8.14', 'Redundancy of information processing facilities', 'Uses appropriate redundancy for information-processing facilities and components to support required availability and resilience.'),
    ('A.8.15', 'Logging', 'Generates, protects and reviews logs of relevant system, user, security and administrative activities for accountability and investigation.'),
    ('A.8.16', 'Monitoring activities', 'Monitors networks, systems and applications for anomalous behaviour and potential information security events.'),
    ('A.8.17', 'Clock synchronization', 'Synchronizes system clocks to approved time sources so timestamps remain consistent for operations, logging and investigations.'),
    ('A.8.18', 'Use of privileged utility programs', 'Restricts and controls privileged utility programs that could bypass normal system or application controls.'),
    ('A.8.19', 'Installation of software on operational systems', 'Controls software installation on operational systems so only authorized and appropriately managed software is introduced.'),
    ('A.8.20', 'Networks security', 'Protects networks and network devices through secure architecture, configuration, management and monitoring.'),
    ('A.8.21', 'Security of network services', 'Defines, implements and monitors security requirements for network services according to business and risk needs.'),
    ('A.8.22', 'Segregation of networks', 'Separates networks, systems and user groups where segregation reduces security risk or limits unauthorized access.'),
    ('A.8.23', 'Web filtering', 'Controls access to malicious, inappropriate or unauthorized web resources to reduce exposure to web-based threats.'),
    ('A.8.24', 'Use of cryptography', 'Uses cryptographic controls and manages cryptographic keys according to information protection and business requirements.'),
    ('A.8.25', 'Secure development life cycle', 'Integrates security activities and controls throughout the system and software development life cycle.'),
    ('A.8.26', 'Application security requirements', 'Identifies, documents and approves information security requirements for applications before development, acquisition or significant change.'),
    ('A.8.27', 'Secure system architecture and engineering principles', 'Applies secure architecture and engineering principles when designing, developing, integrating and maintaining information systems.'),
    ('A.8.28', 'Secure coding', 'Applies secure coding practices to reduce software weaknesses and prevent common implementation vulnerabilities.'),
    ('A.8.29', 'Security testing in development and acceptance', 'Performs security testing during development and acceptance to verify security requirements and identify vulnerabilities before release.'),
    ('A.8.30', 'Outsourced development', 'Manages information security risks associated with externally developed software and outsourced development activities.'),
    ('A.8.31', 'Separation of development, test and production environments', 'Separates development, testing and production environments to reduce unauthorized changes, data exposure and operational disruption.'),
    ('A.8.32', 'Change management', 'Controls changes to information systems and processing facilities through authorization, assessment, testing and documented implementation.'),
    ('A.8.33', 'Test information', 'Protects test data and other information used for testing against unauthorized access, disclosure and inappropriate production-data use.'),
    ('A.8.34', 'Protection of information systems during audit testing', 'Plans and controls audit testing of operational systems to minimize disruption and protect systems and information during audit activities.'),
]


def _category(code):
    if code.startswith('A.5.'):
        return 'Organizational Controls'
    if code.startswith('A.6.'):
        return 'People Controls'
    if code.startswith('A.7.'):
        return 'Physical Controls'
    return 'Technological Controls'


def seed_database(conn):
    cur = conn.cursor()
    if cur.execute('SELECT COUNT(*) FROM Role').fetchone()[0] > 0:
        return

    roles = [
        (1, 'Administrator', 'System administration and audit access'),
        (2, 'Control Owner', 'Assigned controls, evidence and remediation progress'),
        (3, 'Compliance User', 'Assessment, evidence, remediation and reporting'),
        (4, 'Control Owner / Compliance User', 'Combined control-owner and compliance-user permissions for the academic prototype'),
    ]
    cur.executemany('INSERT INTO Role(role_id, role_name, description) VALUES(?,?,?)', roles)

    users = [
        (1, 'Venu Sai Kondapally', 'venu.sai@example.org', hash_password(DEMO_PASSWORD), 1, 1),
        (2, 'Praneeth Kunireddy', 'praneeth.kunireddy@example.org', hash_password(DEMO_PASSWORD), 2, 1),
        (3, 'Siri Lakshmi Vankayalapati', 'siri.lakshmi@example.org', hash_password(DEMO_PASSWORD), 3, 1),
        (4, 'Rohit Rajbanshi', 'rohit.rajbanshi@example.org', hash_password(DEMO_PASSWORD), 4, 1),
    ]
    cur.executemany('INSERT INTO User(user_id,name,email,password_hash,role_id,active) VALUES(?,?,?,?,?,?)', users)

    controls = []
    for cid, (code, title, description) in enumerate(ISO_CONTROLS, start=1):
        owner_id = 2 if cid % 2 else 4
        controls.append((
            cid, code, title, description, _category(code), FRAMEWORK,
            'Applicable', 'Included in the controlled academic demonstration scope.',
            owner_id, '2026-10-01T09:00:00'
        ))
    cur.executemany('''INSERT INTO Control(
        control_id,control_code,title,description,category,framework,applicability,
        applicability_rationale,owner_id,created_date) VALUES(?,?,?,?,?,?,?,?,?,?)''', controls)

    # Stable demonstration distribution across 93 applicable framework controls:
    # 50 Compliant + 15 Partially Compliant + 9 Non-Compliant + 19 Not Assessed.
    special = {
        'A.5.15': ('Partially Compliant', 2,
                   'Quarterly access reviews are performed, but supporting evidence for one business unit is incomplete.',
                   'High', 'Incomplete access-review evidence could delay detection of inappropriate access.', '2026-10-07T10:00:00'),
        'A.5.24': ('Non-Compliant', 1,
                   'The incident management plan requires revision, ownership confirmation and formal approval.',
                   'Critical', 'An incomplete response plan could materially delay coordinated handling of a serious security incident.', '2026-10-02T10:00:00'),
        'A.6.3': ('Partially Compliant', 2,
                  'Awareness training is delivered, but annual completion evidence is incomplete for the current cycle.',
                  'Medium', 'Incomplete training evidence reduces assurance that all personnel received current guidance.', '2026-10-03T10:00:00'),
        'A.8.5': ('Compliant', 4,
                  'Strong authentication is implemented for the demonstration environment and supporting evidence is current.',
                  None, None, '2026-10-05T10:00:00'),
        'A.8.8': ('Partially Compliant', 2,
                  'Vulnerability review is operating, but several high-priority remediation items remain open.',
                  'High', 'Open high-priority vulnerabilities increase exposure until remediation is completed.', '2026-10-06T10:00:00'),
        'A.8.13': ('Compliant', 3,
                   'Backup and recovery testing is documented for the demonstration dataset.',
                   None, None, '2026-10-04T10:00:00'),
    }
    targets = {'Compliant': 50, 'Partially Compliant': 15, 'Non-Compliant': 9}
    counts = {k: 0 for k in targets}
    status_map = {}
    for code, value in special.items():
        status_map[code] = value
        counts[value[0]] += 1

    for cid, (code, title, description) in enumerate(ISO_CONTROLS, start=1):
        if code in status_map:
            continue
        chosen = None
        for status in ('Compliant', 'Partially Compliant', 'Non-Compliant'):
            if counts[status] < targets[status]:
                chosen = status
                break
        if chosen is None:
            continue  # Remaining controls are Not Assessed.
        assessed_day = date(2026, 8, 1) + timedelta(days=(cid * 5) % 72)
        assessed_date = f'{assessed_day.isoformat()}T10:00:00'
        if chosen == 'Compliant':
            maturity = 4 if cid % 3 == 0 else 3
            comments = 'The control is operating as expected for the controlled demonstration scope.'
            risk_rating = None
            risk_rationale = None
        elif chosen == 'Partially Compliant':
            maturity = 2
            comments = 'A defined process exists, but a documentation or implementation gap remains open.'
            risk_rating = 'Medium'
            risk_rationale = 'The identified control gap creates a moderate residual risk until corrective action is completed.'
        else:
            maturity = 1
            comments = 'A material control deficiency has been identified and requires remediation.'
            risk_rating = 'High'
            risk_rationale = 'The identified deficiency could materially affect confidentiality, integrity or availability if left unresolved.'
        status_map[code] = (chosen, maturity, comments, risk_rating, risk_rationale, assessed_date)
        counts[chosen] += 1

    code_to_id = {code: idx for idx, (code, _title, _description) in enumerate(ISO_CONTROLS, start=1)}
    aid = 1
    for code, _title, _description in ISO_CONTROLS:
        if code not in status_map:
            continue
        status, maturity, comments, risk_rating, risk_rationale, assessed_date = status_map[code]
        assessor = 3 if aid % 4 else 4
        cur.execute('''INSERT INTO Assessment(
            assessment_id,control_id,status,maturity_level,comments,risk_rating,risk_rationale,
            assessed_by,assessed_date,record_context) VALUES(?,?,?,?,?,?,?,?,?,?)''',
            (aid, code_to_id[code], status, maturity, comments, risk_rating, risk_rationale,
             assessor, assessed_date, 'Demonstration / Academic Prototype'))
        aid += 1

    gap_codes = [code for code, value in status_map.items() if value[0] in ('Partially Compliant', 'Non-Compliant')]
    preferred = ['A.5.15', 'A.5.24', 'A.8.8', 'A.6.3']
    ordered_gaps = preferred + [c for c in gap_codes if c not in preferred]
    descriptions = {
        'A.5.15': 'Complete missing quarterly access-review evidence for the affected business unit.',
        'A.5.24': 'Revise and formally approve the information security incident management plan.',
        'A.8.8': 'Close the identified high-priority vulnerability remediation backlog.',
        'A.6.3': 'Complete and retain current security awareness training evidence.',
    }
    status_cycle = ['In Progress', 'Overdue', 'Open', 'Open', 'Completed', 'In Progress', 'Open', 'Completed', 'Overdue', 'Open', 'In Progress', 'Completed', 'Open', 'Overdue']
    priorities = ['High', 'Critical', 'High', 'Medium', 'Medium', 'High', 'Medium', 'Low', 'High', 'Medium', 'High', 'Low', 'Medium', 'High']
    actions = []
    for i, code in enumerate(ordered_gaps[:14], start=1):
        cid = code_to_id[code]
        owner = 2 if cid % 2 else 4
        status = status_cycle[i-1]
        priority = priorities[i-1]
        if status == 'Overdue':
            due = date(2026, 10, 10) - timedelta(days=i % 3)
        elif status == 'Completed':
            due = date(2026, 10, 12) + timedelta(days=i)
        else:
            due = date(2026, 10, 22) + timedelta(days=i)
        completed = '2026-10-12T15:00:00' if status == 'Completed' else None
        desc = descriptions.get(code, f'Complete corrective action for the identified {code} control deficiency.')
        actions.append((i, cid, owner, desc, priority, status, due.isoformat(), '2026-10-08T09:00:00', completed))
    cur.executemany('''INSERT INTO RemediationAction(
        action_id,control_id,owner_id,description,priority,status,due_date,created_date,completed_date)
        VALUES(?,?,?,?,?,?,?,?,?)''', actions)

    evidence_rows = [
        (31, code_to_id['A.5.15'], 'Quarterly Access Review',
         'Demonstration evidence supporting the access-control review.',
         'Q3_Access_Review.pdf', 'Q3_Access_Review.pdf', 2, '2026-10-07T12:00:00'),
        (32, code_to_id['A.8.5'], 'Secure Authentication Configuration',
         'Demonstration screenshot supporting the secure-authentication assessment.',
         'MFA_Config.png', 'MFA_Config.png', 3, '2026-10-08T12:00:00'),
    ]
    cur.executemany('''INSERT INTO Evidence(
        evidence_id,control_id,title,description,file_name,file_path,uploaded_by,uploaded_date)
        VALUES(?,?,?,?,?,?,?,?)''', evidence_rows)

    audit_rows = [
        (1, 3, 'Assessment Updated', 'Assessment', 1, 'A.5.15 assessment saved with High risk rating', '2026-10-14T14:32:00'),
        (2, 3, 'Evidence Uploaded', 'Evidence', 32, 'MFA_Config.png', '2026-10-14T13:45:00'),
        (3, 2, 'Remediation Updated', 'RemediationAction', 1, 'RA-001 status changed to In Progress', '2026-10-14T11:18:00'),
        (4, 1, 'User Updated', 'User', 4, 'Rohit Rajbanshi role/active status reviewed', '2026-10-14T09:05:00'),
        (5, 4, 'Report Generated', 'Report', None, 'Compliance Summary; period=Current; category=All; status=All', '2026-10-14T15:05:00'),
    ]
    cur.executemany('INSERT INTO AuditLog(log_id,user_id,action,entity_type,entity_id,details,timestamp) VALUES(?,?,?,?,?,?,?)', audit_rows)
    conn.commit()
