from datetime import datetime
from io import BytesIO
from pathlib import Path
from uuid import uuid4
import zipfile
from flask import Blueprint, abort, current_app, flash, g, redirect, render_template, request, send_from_directory, url_for
from werkzeug.utils import secure_filename
from app.db import get_db
from app.utils import audit, login_required, user_has_role

bp = Blueprint('evidence', __name__, url_prefix='/evidence')
ALLOWED_EXTENSIONS = {'pdf', 'docx', 'xlsx', 'png', 'jpg', 'jpeg'}


def _extension(filename):
    return filename.rsplit('.', 1)[1].lower() if '.' in filename else ''


def allowed(filename):
    return _extension(filename) in ALLOWED_EXTENSIONS


def validate_content(file_storage):
    ext = _extension(file_storage.filename or '')
    data = file_storage.stream.read()
    file_storage.stream.seek(0)
    if not data:
        return False
    if ext == 'pdf':
        return data.startswith(b'%PDF-')
    if ext == 'png':
        return data.startswith(b'\x89PNG\r\n\x1a\n')
    if ext in ('jpg', 'jpeg'):
        return data.startswith(b'\xff\xd8\xff')
    if ext in ('docx', 'xlsx'):
        try:
            with zipfile.ZipFile(BytesIO(data)) as archive:
                names = set(archive.namelist())
                if '[Content_Types].xml' not in names:
                    return False
                prefix = 'word/' if ext == 'docx' else 'xl/'
                return any(name.startswith(prefix) for name in names)
        except zipfile.BadZipFile:
            return False
    return False


def _control_for_user(db, control_id):
    control = db.execute('''SELECT c.*, u.name owner_name FROM Control c
                            LEFT JOIN User u ON u.user_id=c.owner_id
                            WHERE c.control_id=?''', (control_id,)).fetchone()
    if control is None:
        abort(404)
    can_view = user_has_role('Administrator') or user_has_role('Compliance User') or (
        user_has_role('Control Owner') and control['owner_id'] == g.user['user_id']
    )
    if not can_view:
        abort(403)
    return control


@bp.route('/<int:control_id>', methods=['GET', 'POST'])
@login_required
def manage(control_id):
    db = get_db()
    control = _control_for_user(db, control_id)
    can_upload = user_has_role('Compliance User') or (
        user_has_role('Control Owner') and control['owner_id'] == g.user['user_id']
    )
    if request.method == 'POST':
        if not can_upload:
            abort(403)
        title = request.form.get('title', '').strip()
        description = request.form.get('description', '').strip()
        file = request.files.get('file')
        if not title or not file or not file.filename:
            flash('Evidence title and file are required.', 'danger')
        elif not allowed(file.filename):
            flash('File type not allowed. Use PDF, DOCX, XLSX, PNG, JPG or JPEG.', 'danger')
        elif not validate_content(file):
            flash('File content does not match the allowed file type.', 'danger')
        else:
            original = secure_filename(file.filename)
            stored = f'{uuid4().hex}_{original}'
            upload_dir = Path(current_app.config['UPLOAD_FOLDER'])
            upload_dir.mkdir(parents=True, exist_ok=True)
            destination = upload_dir / stored
            file.save(destination)
            # Evidence is stored outside /static and served only through the authorised download route.
            cur = db.execute('''INSERT INTO Evidence(control_id,title,description,file_name,file_path,uploaded_by,uploaded_date)
                                VALUES(?,?,?,?,?,?,?)''',
                             (control_id, title, description, original, stored, g.user['user_id'],
                              datetime.now().isoformat(timespec='seconds')))
            db.commit()
            audit('Evidence Uploaded', 'Evidence', cur.lastrowid, original)
            flash('Evidence uploaded successfully.', 'success')
            return redirect(url_for('evidence.manage', control_id=control_id))

    latest = db.execute('''SELECT status FROM Assessment WHERE control_id=?
                           ORDER BY assessed_date DESC,assessment_id DESC LIMIT 1''', (control_id,)).fetchone()
    evidence = db.execute('''SELECT e.*, u.name uploader_name FROM Evidence e JOIN User u ON u.user_id=e.uploaded_by
                             WHERE e.control_id=? ORDER BY e.uploaded_date DESC,e.evidence_id DESC''', (control_id,)).fetchall()
    return render_template(
        'evidence.html', control=control,
        current_status=(latest['status'] if latest else 'Not Assessed'),
        evidence=evidence, can_upload=can_upload
    )


@bp.route('/download/<int:evidence_id>')
@login_required
def download(evidence_id):
    db = get_db()
    row = db.execute('SELECT * FROM Evidence WHERE evidence_id=?', (evidence_id,)).fetchone()
    if row is None:
        abort(404)
    _control_for_user(db, row['control_id'])
    path = Path(current_app.config['UPLOAD_FOLDER']) / row['file_path']
    if not path.exists():
        flash('The demonstration file is not present on this environment.', 'warning')
        return redirect(url_for('evidence.manage', control_id=row['control_id']))
    audit('Evidence Downloaded', 'Evidence', evidence_id, row['file_name'])
    return send_from_directory(
        current_app.config['UPLOAD_FOLDER'], row['file_path'], as_attachment=True,
        download_name=row['file_name']
    )
