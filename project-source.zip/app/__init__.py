from pathlib import Path


def create_app(test_config=None):
    from flask import Flask, g, render_template, session
    from config import Config
    from .db import close_db, get_db, ensure_database
    from .csrf import generate_csrf_token, validate_csrf_request
    from .utils import role_allows

    app = Flask(__name__, instance_relative_config=False)
    app.config.from_object(Config)

    if test_config:
        app.config.update(test_config)

    # Production security checks
    if app.config.get('PRODUCTION_MODE'):
        secret_key = app.config.get('SECRET_KEY', '')

        weak_secret = (
            secret_key in (
                None,
                '',
                'dev-only-change-me-before-cloud-deployment'
            )
            or len(secret_key) < 32
        )

        if weak_secret:
            raise RuntimeError(
                'Production mode requires a strong SECRET_KEY '
                'of at least 32 characters.'
            )

        if not app.config.get('SESSION_COOKIE_SECURE'):
            raise RuntimeError(
                'Production mode requires SESSION_COOKIE_SECURE=1 '
                'after HTTPS is configured.'
            )

    # Ensure required folders/database exist
    Path(app.config['UPLOAD_FOLDER']).mkdir(
        parents=True,
        exist_ok=True
    )

    Path(app.config['DATABASE']).parent.mkdir(
        parents=True,
        exist_ok=True
    )

    ensure_database(app.config['DATABASE'])
    app.teardown_appcontext(close_db)

    # ---------------------------------------------------------
    # Load user BEFORE CSRF validation.
    #
    # This ensures g.user always exists even when a request is
    # rejected by CSRF validation and Flask renders the 400 page.
    # ---------------------------------------------------------
    @app.before_request
    def load_logged_in_user():
        g.user = None

        user_id = session.get('user_id')

        if user_id is not None:
            row = get_db().execute(
                '''
                SELECT
                    u.user_id,
                    u.name,
                    u.email,
                    u.active,
                    u.role_id,
                    r.role_name
                FROM User u
                JOIN Role r
                    ON r.role_id = u.role_id
                WHERE u.user_id = ?
                ''',
                (user_id,)
            ).fetchone()

            if row and row['active']:
                g.user = row
            else:
                session.clear()

    # CSRF validation runs after g.user has been initialised
    @app.before_request
    def validate_csrf():
        validate_csrf_request()

    # Template helpers
    @app.context_processor
    def inject_user():
        current_user = getattr(g, 'user', None)

        def has_role(role_name):
            return bool(
                current_user
                and role_allows(
                    current_user['role_name'],
                    role_name
                )
            )

        return {
            'current_user': current_user,
            'csrf_token': generate_csrf_token,
            'has_role': has_role,
        }

    # Register application blueprints
    from .auth.routes import bp as auth_bp
    from .dashboard.routes import bp as dashboard_bp
    from .controls.routes import bp as controls_bp
    from .assessments.routes import bp as assessments_bp
    from .evidence.routes import bp as evidence_bp
    from .remediation.routes import bp as remediation_bp
    from .reports.routes import bp as reports_bp
    from .audit.routes import bp as audit_bp
    from .admin.routes import bp as admin_bp

    blueprints = [
        auth_bp,
        dashboard_bp,
        controls_bp,
        assessments_bp,
        evidence_bp,
        remediation_bp,
        reports_bp,
        audit_bp,
        admin_bp,
    ]

    for bp in blueprints:
        app.register_blueprint(bp)

    # ---------------------------------------------------------
    # Error handlers
    # ---------------------------------------------------------
    @app.errorhandler(400)
    def bad_request(error):
        return render_template(
            '400.html',
            message=getattr(
                error,
                'description',
                'Bad request.'
            )
        ), 400

    @app.errorhandler(403)
    def forbidden(_):
        return render_template(
            '403.html'
        ), 403

    @app.errorhandler(404)
    def not_found(_):
        return render_template(
            '404.html'
        ), 404

    @app.errorhandler(413)
    def too_large(_):
        return render_template(
            '413.html'
        ), 413

    return app