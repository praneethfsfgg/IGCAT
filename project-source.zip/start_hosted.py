"""Initialise only a new demo database, then start the production HTTP server."""
import os
from pathlib import Path

os.environ.setdefault('APP_ENV', 'production')
os.environ.setdefault('SESSION_COOKIE_SECURE', '1')
os.environ.setdefault('FLASK_DEBUG', '0')
os.environ.setdefault('DATABASE', '/data/isms.db')
os.environ.setdefault('UPLOAD_FOLDER', '/data/uploads')
if len(os.environ.get('SECRET_KEY', '')) < 32:
    raise RuntimeError('Set a random SECRET_KEY of at least 32 characters in hosting variables.')
if not Path('/data').is_mount():
    raise RuntimeError('Attach persistent storage at /data before starting the hosted app.')
from app import create_app
from app.database import connect
from app.seed import seed_database
from app.security import hash_password
app = create_app()
with connect(app.config['DATABASE']) as db:
    if db.execute('SELECT COUNT(*) FROM User').fetchone()[0] == 0:
        password = os.environ.get('INITIAL_DEMO_PASSWORD', '')
        if len(password) < 16:
            raise RuntimeError('Set INITIAL_DEMO_PASSWORD of at least 16 characters for initial demo accounts.')
        seed_database(db)
        db.execute('UPDATE User SET password_hash=?', (hash_password(password),))
        db.commit()
        # Copy only synthetic evidence provided by the original project.
        import scripts.reset_demo as samples
        samples.UPLOADS = Path(app.config['UPLOAD_FOLDER'])
        samples.ensure_sample_files()
os.execvp('gunicorn', ['gunicorn', '--bind', '0.0.0.0:' + os.environ.get('PORT', '8080'), '--workers', '1', '--threads', '4', '--timeout', '90', '--access-logfile', '-', 'run:app'])
