from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
DB = ROOT / 'instance' / 'isms.db'
UPLOADS = ROOT / 'instance' / 'uploads'
