import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from app.database import init_database
from scripts.common import DB, UPLOADS

if __name__=='__main__':
    UPLOADS.mkdir(parents=True,exist_ok=True)
    conn=init_database(DB,reset=False); conn.close()
    print(f'Database initialised: {DB}')
