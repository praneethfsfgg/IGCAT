# ISMS Gap Analysis and Compliance Tracking Platform

## Run in VS Code (Windows)

1. Extract the project ZIP and open this folder in VS Code.
2. Open **Terminal > New Terminal**.
3. Run:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements-dev.txt
python scripts\reset_demo.py
pytest -q
python run.py
```

4. Open `http://127.0.0.1:5000` in a browser.

If PowerShell blocks virtual-environment activation, run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

## Demo Accounts

Password for all demo accounts: `DemoPass!2026`

- Administrator — Venu Sai Kondapally — `venu.sai@example.org`
- Compliance User — Siri Lakshmi Vankayalapati — `siri.lakshmi@example.org`
- Control Owner — Praneeth Kunireddy — `praneeth.kunireddy@example.org`
- Control Owner / Compliance User — Rohit Rajbanshi — `rohit.rajbanshi@example.org`

## Test Evidence

`AUTOMATED_TEST_RESULTS.txt` contains the recorded automated-test result.
`RUNTIME_VALIDATION_RESULTS.txt` summarises the completed local runtime and workflow verification.
