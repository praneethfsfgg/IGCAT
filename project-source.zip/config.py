import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-only-change-me-before-cloud-deployment')
    DATABASE = os.environ.get('DATABASE', str(BASE_DIR / 'instance' / 'isms.db'))
    UPLOAD_FOLDER = os.environ.get('UPLOAD_FOLDER', str(BASE_DIR / 'instance' / 'uploads'))
    MAX_CONTENT_LENGTH = 10 * 1024 * 1024
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    SESSION_COOKIE_SECURE = os.environ.get('SESSION_COOKIE_SECURE', '0') == '1'
    CSRF_ENABLED = os.environ.get('CSRF_ENABLED', '1') != '0'
    PRODUCTION_MODE = os.environ.get('APP_ENV', '').lower() == 'production'
