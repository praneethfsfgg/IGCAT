from .conftest import login


def test_dashboard_metrics(client):
    login(client)
    r = client.get('/dashboard/')
    assert r.status_code == 200
    assert b'68%' in r.data
    assert b'74 / 93' in r.data
    assert b'24' in r.data
    assert b'Compliance = Compliant applicable assessed controls' in r.data


def test_dashboard_reflects_latest_saved_assessment(client):
    login(client)
    # A.8.34 is seeded as Not Assessed. Saving a compliant assessment should increase assessed count.
    r = client.post('/assessments/93', data={
        'status': 'Compliant',
        'maturity_level': '3',
        'comments': 'Validated during automated regression testing.',
        'risk_rating': '',
        'risk_rationale': '',
        'remediation_required': 'no',
    }, follow_redirects=True)
    assert b'Assessment saved successfully' in r.data
    dash = client.get('/dashboard/')
    assert b'75 / 93' in dash.data
