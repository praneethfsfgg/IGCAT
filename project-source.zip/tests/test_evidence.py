from io import BytesIO
from .conftest import login

PDF = b'%PDF-1.4\n1 0 obj\n<<>>\nendobj\n%%EOF\n'


def test_valid_evidence_upload(client, app):
    login(client)
    r = client.post('/evidence/15', data={
        'title': 'Test PDF', 'description': 'demo', 'file': (BytesIO(PDF), 'test.pdf')
    }, content_type='multipart/form-data', follow_redirects=True)
    assert b'Evidence uploaded successfully' in r.data
    with app.app_context():
        from app.db import get_db
        assert get_db().execute("SELECT COUNT(*) FROM Evidence WHERE title='Test PDF'").fetchone()[0] == 1


def test_invalid_extension_rejected(client):
    login(client)
    r = client.post('/evidence/15', data={
        'title': 'Bad', 'file': (BytesIO(b'bad'), 'malware.exe')
    }, content_type='multipart/form-data', follow_redirects=True)
    assert b'File type not allowed' in r.data


def test_disguised_file_content_rejected(client):
    login(client)
    r = client.post('/evidence/15', data={
        'title': 'Disguised', 'file': (BytesIO(b'<html>not a pdf</html>'), 'fake.pdf')
    }, content_type='multipart/form-data', follow_redirects=True)
    assert b'File content does not match the allowed file type' in r.data


def test_oversized_evidence_rejected(client):
    login(client)
    r = client.post('/evidence/15', data={
        'title': 'Too large', 'file': (BytesIO(b'%PDF-' + b'x' * (10 * 1024 * 1024 + 100)), 'large.pdf')
    }, content_type='multipart/form-data')
    assert r.status_code == 413


def test_owner_can_access_owned_evidence(client):
    login(client, 'praneeth.kunireddy@example.org')
    r = client.get('/evidence/15')
    assert r.status_code == 200
    assert b'Quarterly Access Review' in r.data


def test_owner_blocked_from_unowned_evidence(client):
    login(client, 'praneeth.kunireddy@example.org')
    # Control 16 belongs to Rohit Rajbanshi.
    r = client.get('/evidence/16')
    assert r.status_code == 403


def test_owner_blocked_from_unowned_evidence_download(client):
    login(client, 'praneeth.kunireddy@example.org')
    # Evidence 32 is linked to A.8.5, an even control owned by Rohit.
    r = client.get('/evidence/download/32')
    assert r.status_code == 403
