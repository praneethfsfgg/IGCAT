from .conftest import login


def test_assessment_save_risk_and_persist(client, app):
    login(client)
    r = client.post('/assessments/93', data={
        'status': 'Partially Compliant',
        'maturity_level': '2',
        'comments': 'Test control deficiency',
        'risk_rating': 'High',
        'risk_rationale': 'The gap could allow an untested security condition to persist.',
        'remediation_required': 'no',
    }, follow_redirects=True)
    assert b'Assessment saved successfully' in r.data
    with app.app_context():
        from app.db import get_db
        row = get_db().execute('''SELECT status,maturity_level,risk_rating,risk_rationale
                                  FROM Assessment WHERE control_id=93 ORDER BY assessment_id DESC LIMIT 1''').fetchone()
        assert row['status'] == 'Partially Compliant'
        assert row['maturity_level'] == 2
        assert row['risk_rating'] == 'High'
        assert row['risk_rationale']


def test_gap_assessment_requires_risk_rationale(client):
    login(client)
    r = client.post('/assessments/93', data={
        'status': 'Non-Compliant',
        'maturity_level': '1',
        'comments': 'Gap found',
        'risk_rating': '',
        'risk_rationale': '',
        'remediation_required': 'no',
    }, follow_redirects=True)
    assert b'Risk rating and risk rationale are required' in r.data


def test_assessment_creates_linked_remediation(client, app):
    login(client)
    r = client.post('/assessments/93', data={
        'status': 'Non-Compliant',
        'maturity_level': '1',
        'comments': 'Gap found',
        'risk_rating': 'High',
        'risk_rationale': 'Material control weakness requires correction.',
        'remediation_required': 'yes',
        'action_description': 'Fix automated test gap',
        'owner_id': '2',
        'priority': 'High',
        'due_date': '2026-12-01',
    }, follow_redirects=True)
    assert b'Assessment saved successfully' in r.data
    with app.app_context():
        from app.db import get_db
        row = get_db().execute("SELECT * FROM RemediationAction WHERE description='Fix automated test gap'").fetchone()
        assert row is not None
        assert row['control_id'] == 93


def test_control_owner_cannot_assess(client):
    login(client, 'praneeth.kunireddy@example.org')
    r = client.post('/assessments/15', data={
        'status': 'Compliant', 'maturity_level': '3', 'comments': 'Owner attempted assessment',
        'remediation_required': 'no'
    })
    assert r.status_code == 403
