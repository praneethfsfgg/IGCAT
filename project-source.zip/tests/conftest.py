import pytest
from app import create_app
from app.database import init_database
from app.seed import seed_database


@pytest.fixture
def app(tmp_path):
    db_path = tmp_path / 'test.db'
    uploads = tmp_path / 'uploads'
    uploads.mkdir()
    conn = init_database(db_path, reset=True)
    seed_database(conn)
    conn.close()
    app = create_app({
        'TESTING': True,
        'DATABASE': str(db_path),
        'UPLOAD_FOLDER': str(uploads),
        'SECRET_KEY': 'test-secret-key-for-automated-tests',
        'MAX_CONTENT_LENGTH': 10 * 1024 * 1024,
        'CSRF_ENABLED': False,
    })
    return app


@pytest.fixture
def client(app):
    return app.test_client()


def login(client, email='siri.lakshmi@example.org', password='DemoPass!2026'):
    return client.post('/login', data={'email': email, 'password': password}, follow_redirects=True)
