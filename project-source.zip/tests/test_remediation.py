from .conftest import login


def test_create_remediation(client, app):
    login(client)
    r = client.post('/remediation/create', data={
        'control_id': '15', 'owner_id': '2', 'description': 'Formal test action',
        'priority': 'High', 'due_date': '2026-12-10'
    }, follow_redirects=True)
    assert b'Remediation action created' in r.data


def test_update_remediation_and_audit(client, app):
    login(client)
    r = client.post('/remediation/1/update', data={'status': 'Completed'}, follow_redirects=True)
    assert b'Remediation action updated' in r.data
    with app.app_context():
        from app.db import get_db
        db = get_db()
        assert db.execute('SELECT status FROM RemediationAction WHERE action_id=1').fetchone()['status'] == 'Completed'
        assert db.execute("SELECT COUNT(*) FROM AuditLog WHERE action='Remediation Updated' AND entity_id=1").fetchone()[0] >= 1


def test_overdue_action_is_identified(client):
    login(client)
    r = client.get('/remediation/?q=RA-002')
    assert r.status_code == 200
    assert b'Overdue' in r.data
    assert b'A.5.24' in r.data
