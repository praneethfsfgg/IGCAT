from .conftest import login


def test_report_loads_and_generates(client):
    login(client)
    r = client.post('/reports/', data={
        'report_type': 'Compliance Summary', 'period': 'Current', 'category': '', 'status': ''
    }, follow_redirects=True)
    assert r.status_code == 200
    assert b'Report Preview' in r.data
    assert b'Compliance Breakdown' in r.data
    assert b'68%' in r.data
    assert b'74 / 93' in r.data


def test_report_period_filter_is_functional(client):
    login(client)
    r = client.post('/reports/', data={
        'report_type': 'Assessment Summary', 'period': 'Last 30 Days', 'category': '', 'status': ''
    }, follow_redirects=True)
    assert r.status_code == 200
    assert b'Period: Last 30 Days' in r.data
    assert b'Assessment Summary' in r.data
    assert b'74 / 93' not in r.data


def test_report_type_filter_is_functional(client):
    login(client)
    r = client.post('/reports/', data={
        'report_type': 'Overdue Actions Report', 'period': 'Current', 'category': '', 'status': ''
    }, follow_redirects=True)
    assert b'Report Preview' in r.data
    assert b'Overdue Actions Report' in r.data


def test_pdf_export(client):
    login(client)
    r = client.get('/reports/export.pdf?report_type=Compliance+Summary&period=Current')
    assert r.status_code == 200
    assert r.mimetype == 'application/pdf'
    assert r.data.startswith(b'%PDF')
