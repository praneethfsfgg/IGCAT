from .conftest import login


def test_admin_audit_access(client):
    login(client, 'venu.sai@example.org')
    r = client.get('/audit/')
    assert r.status_code == 200
    assert b'Activity Records' in r.data
    assert b'Venu Sai Kondapally' in r.data


def test_compliance_user_blocked_from_admin(client):
    login(client)
    r = client.get('/admin/users')
    assert r.status_code == 403


def test_owner_only_sees_assigned_remediation(client):
    login(client, 'praneeth.kunireddy@example.org')
    r = client.get('/remediation/')
    assert r.status_code == 200
    assert b'Remediation Actions' in r.data
    assert b'Praneeth Kunireddy' in r.data


def test_owner_blocked_from_unassigned_action(client):
    login(client, 'praneeth.kunireddy@example.org')
    # RA-002 is assigned to Rohit Rajbanshi.
    r = client.post('/remediation/2/update', data={'status': 'Completed'})
    assert r.status_code == 403


def test_hybrid_user_has_compliance_permissions(client):
    login(client, 'rohit.rajbanshi@example.org')
    reports = client.get('/reports/')
    create = client.get('/remediation/create')
    assert reports.status_code == 200
    assert create.status_code == 200
    assert b'Rohit Rajbanshi' in reports.data
