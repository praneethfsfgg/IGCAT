from .conftest import login


def test_valid_login(client):
    r = login(client)
    assert r.status_code == 200
    assert b'Dashboard' in r.data
    assert b'Siri Lakshmi Vankayalapati' in r.data


def test_invalid_login(client):
    r = client.post('/login', data={'email': 'siri.lakshmi@example.org', 'password': 'wrong'})
    assert r.status_code == 401
    assert b'Invalid email address or password' in r.data


def test_logout(client):
    login(client)
    r = client.post('/logout', follow_redirects=True)
    assert b'Sign in' in r.data


def test_protected_requires_login(client):
    r = client.get('/dashboard/', follow_redirects=False)
    assert r.status_code in (301, 302)
    assert '/login?next=/dashboard/' in r.headers['Location']


def test_inactive_user_cannot_login(client, app):
    with app.app_context():
        from app.db import get_db
        db = get_db()
        db.execute('UPDATE User SET active=0 WHERE email=?', ('siri.lakshmi@example.org',))
        db.commit()
    r = client.post('/login', data={'email': 'siri.lakshmi@example.org', 'password': 'DemoPass!2026'})
    assert r.status_code == 401
