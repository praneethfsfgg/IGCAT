from .conftest import login


def test_control_register_loads_iso_framework(client):
    login(client)
    r = client.get('/controls/')
    assert r.status_code == 200
    assert b'ISO/IEC 27001:2022 Annex A' in r.data
    assert b'A.5.1' in r.data
    assert b'Policies for information security' in r.data


def test_control_search(client):
    login(client)
    r = client.get('/controls/?q=A.5.15')
    assert b'A.5.15' in r.data
    assert b'Access control' in r.data


def test_control_register_has_93_framework_controls(app):
    with app.app_context():
        from app.db import get_db
        db = get_db()
        assert db.execute('SELECT COUNT(*) FROM Control').fetchone()[0] == 93
        assert db.execute("SELECT COUNT(*) FROM Control WHERE framework='ISO/IEC 27001:2022 Annex A'").fetchone()[0] == 93
        assert db.execute("SELECT COUNT(*) FROM Control WHERE applicability='Applicable'").fetchone()[0] == 93


def test_owner_control_register_is_restricted(client):
    login(client, 'praneeth.kunireddy@example.org')
    r = client.get('/controls/')
    assert r.status_code == 200
    assert b'Praneeth Kunireddy' in r.data
    assert b'Rohit Rajbanshi' not in r.data or b'Control Owner / Compliance User' not in r.data
