from .conftest import login


def test_login_creates_audit_record(client, app):
    login(client)
    with app.app_context():
        from app.db import get_db
        assert get_db().execute("SELECT COUNT(*) FROM AuditLog WHERE action='Login'").fetchone()[0] >= 1


def test_assessment_and_evidence_actions_are_auditable(client, app):
    from io import BytesIO
    login(client)
    client.post('/assessments/93', data={
        'status': 'Compliant', 'maturity_level': '3', 'comments': 'Audit test',
        'risk_rating': '', 'risk_rationale': '', 'remediation_required': 'no'
    }, follow_redirects=True)
    client.post('/evidence/15', data={
        'title': 'Audit evidence', 'file': (BytesIO(b'%PDF-1.4\n%%EOF\n'), 'audit.pdf')
    }, content_type='multipart/form-data', follow_redirects=True)
    with app.app_context():
        from app.db import get_db
        db = get_db()
        assert db.execute("SELECT COUNT(*) FROM AuditLog WHERE action='Assessment Updated'").fetchone()[0] >= 1
        assert db.execute("SELECT COUNT(*) FROM AuditLog WHERE action='Evidence Uploaded'").fetchone()[0] >= 1
