from .conftest import login


def test_administrator_can_create_user(client, app):
    login(client, 'venu.sai@example.org')
    r = client.post('/admin/users', data={
        'name': 'Demo Test Owner',
        'email': 'demo.owner@example.org',
        'password': 'DemoPass!2026',
        'role_id': '2',
    }, follow_redirects=True)
    assert r.status_code == 200
    assert b'User created.' in r.data
    assert b'Demo Test Owner' in r.data
    with app.app_context():
        from app.db import get_db
        assert get_db().execute("SELECT COUNT(*) FROM User WHERE email='demo.owner@example.org'").fetchone()[0] == 1


def test_seeded_user_names_match_assigned_roles(app):
    with app.app_context():
        from app.db import get_db
        rows = get_db().execute('''SELECT u.name,r.role_name FROM User u JOIN Role r ON r.role_id=u.role_id ORDER BY u.user_id''').fetchall()
        assert [(r['name'], r['role_name']) for r in rows] == [
            ('Venu Sai Kondapally', 'Administrator'),
            ('Praneeth Kunireddy', 'Control Owner'),
            ('Siri Lakshmi Vankayalapati', 'Compliance User'),
            ('Rohit Rajbanshi', 'Control Owner / Compliance User'),
        ]
