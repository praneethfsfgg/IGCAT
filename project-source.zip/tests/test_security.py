import re
import pytest
from app import create_app
from .conftest import login


def test_csrf_blocks_state_change_without_token(client, app):
    app.config['CSRF_ENABLED'] = True
    # GET login creates the session token because the template renders csrf_token().
    page = client.get('/login')
    match = re.search(rb'name="_csrf_token" value="([^"]+)"', page.data)
    assert match
    token = match.group(1).decode()

    blocked = client.post('/login', data={'email': 'siri.lakshmi@example.org', 'password': 'DemoPass!2026'})
    assert blocked.status_code == 400

    allowed = client.post('/login', data={
        '_csrf_token': token,
        'email': 'siri.lakshmi@example.org',
        'password': 'DemoPass!2026'
    }, follow_redirects=True)
    assert allowed.status_code == 200
    assert b'Dashboard' in allowed.data


def test_production_mode_rejects_weak_secret(tmp_path):
    uploads = tmp_path / 'uploads'
    uploads.mkdir()
    with pytest.raises(RuntimeError, match='strong SECRET_KEY'):
        create_app({
            'TESTING': True,
            'DATABASE': str(tmp_path / 'prod.db'),
            'UPLOAD_FOLDER': str(uploads),
            'PRODUCTION_MODE': True,
            'SECRET_KEY': 'weak',
            'SESSION_COOKIE_SECURE': True,
        })


def test_production_mode_requires_secure_cookie(tmp_path):
    uploads = tmp_path / 'uploads2'
    uploads.mkdir()
    with pytest.raises(RuntimeError, match='SESSION_COOKIE_SECURE'):
        create_app({
            'TESTING': True,
            'DATABASE': str(tmp_path / 'prod2.db'),
            'UPLOAD_FOLDER': str(uploads),
            'PRODUCTION_MODE': True,
            'SECRET_KEY': 'x' * 48,
            'SESSION_COOKIE_SECURE': False,
        })
